﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Inventorysystem.Models;

namespace Inventorysystem.Controllers
{
    public class InventoryController : Controller
    {
        // GET: Inventory
        DataClasses1DataContext cx = new DataClasses1DataContext();
        public ActionResult CategoryList()
        {
            return View();
        }
        public ActionResult GroceryList()
        {
            return View(cx.Groceries.ToList());
        }
        public ActionResult CosmeticsList()
        {
            return View(cx.Cosmetics.ToList());
        }
        public ActionResult ToysList()
        {
            return View(cx.Toys.ToList());
        }
        public ActionResult DecorationList()
        {
            return View(cx.Decorations.ToList());
        }
        public ActionResult AddGrocery()
        {       
            return View();
        }
        public ActionResult AddCosmetic()
        {
            return View();
        }
        public ActionResult AddDecoration()
        {
            return View();
        }
        public ActionResult AddToy()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddGroceryItem()
        {
            string name = Request["t1"];
            string price = Request["t2"];
            string brand = Request["t3"];
            Grocery g = new Grocery();
            g.GItemName = name;
            g.GItemBrand = brand;
            g.GItemPrice = price;
            cx.Groceries.InsertOnSubmit(g);
            cx.SubmitChanges();
            return RedirectToAction("GroceryList");
        }
        public ActionResult AddDecorationItem()
        {
            string name = Request["t1"];
            string price = Request["t2"];
            string brand = Request["t3"];
            Decoration g = new Decoration();
            g.DItemName = name;
            g.DItemBrand = brand;
            g.DItemPrice = price;
            cx.Decorations.InsertOnSubmit(g);
            cx.SubmitChanges();
            return RedirectToAction("DecorationList");
        }
        public ActionResult AddToyItem()
        {
            string name = Request["t1"];
            string price = Request["t2"];
            string brand = Request["t3"];
            Toy g = new Toy();
            g.TItemName = name;
            g.TItemBrand = brand;
            g.TItemPrice = price;
            cx.Toys.InsertOnSubmit(g);
            cx.SubmitChanges();
            return RedirectToAction("ToysList");
        }
        public ActionResult AddCosmeticItem()
        {
            string name = Request["t1"];
            string price = Request["t2"];
            string brand = Request["t3"];
            Cosmetic g = new Cosmetic();
            g.CItemNmae = name;
            g.CItemBrand = brand;
            g.CItemPrice = price;
            cx.Cosmetics.InsertOnSubmit(g);
            cx.SubmitChanges();
            return RedirectToAction("CosmeticsList");
        } 
        public ActionResult EditGrocery(int id)
        {
            Grocery grocery = cx.Groceries.First(x => x.Id == id);
            return View(grocery);
        }
        public ActionResult UpdateConfirmGrocery(Grocery grocery)
        {
            var s = cx.Groceries.First(x => x.Id == grocery.Id);
            s.GItemName = grocery.GItemName;
            s.GItemPrice = grocery.GItemPrice;
            s.GItemBrand = grocery.GItemBrand;
            cx.SubmitChanges();
            return RedirectToAction("GroceryList"); 
        }
        public ActionResult EditDecoration(int id)
        {
            Decoration decoration = cx.Decorations.First(x => x.Id == id);
            return View(decoration);
        }
        public ActionResult UpdateConfirmDecoration(Decoration decoration)
        {
            var s = cx.Decorations.First(x => x.Id == decoration.Id);
            s.DItemName = decoration.DItemName;
            s.DItemPrice = decoration.DItemPrice;
            s.DItemBrand = decoration.DItemBrand;
            cx.SubmitChanges();
            return RedirectToAction("DecorationList");
        }
        public ActionResult EditCosmetic(int id)
        {
            Cosmetic cosmetic = cx.Cosmetics.First(x => x.Id == id);
            return View(cosmetic);
        }
        public ActionResult UpdateConfirmCosmetic(Cosmetic cosmetic)
        {
            var s = cx.Cosmetics.First(x => x.Id == cosmetic.Id);
            s.CItemNmae = cosmetic.CItemNmae;
            s.CItemPrice = cosmetic.CItemPrice;
            s.CItemBrand = cosmetic.CItemBrand;
            cx.SubmitChanges();
            return RedirectToAction("CosmeticsList");
        }
        public ActionResult EditToy(int id)
        {
            Toy toy = cx.Toys.First(x => x.Id == id);
            return View(toy);
        }
        public ActionResult UpdateConfirmToy(Toy toy)
        {
            var s = cx.Toys.First(x => x.Id == toy.Id);
            s.TItemName = toy.TItemName;
            s.TItemPrice = toy.TItemPrice;
            s.TItemBrand = toy.TItemBrand;
            cx.SubmitChanges();
            return RedirectToAction("ToysList");
        }
    }
}